// -------------REPL-------------------
5+3
var sum=_
console.log(sum)
console.log("Hello world")
repl.repl.ignoreUndefined=true
console.log("Hello world")
console.log(sum)
varb=15
var b=15
console.log(b)
const c=20
do{
sum++;
console.log(sum);
}while(sum<20);
function add(a,b)
{
return (a+b);
}
console.log(add(5,7));