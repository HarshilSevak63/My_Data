const express=require('express');
const app=express();
const mid=(req,res,next)=>{
console.log('Middelware is called.');
res.write('From global middelware.');
next();
};

app.use(mid);
app.get('/',(req,res)=>{
    res.write('\nIn Home Page');
    res.end();
});
app.listen(4001,()=>console.log('Listening at http://localhost:4001'));
