
import socket
import time

clientserver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
serveraddr = ('localhost', 5000)

# Get input from the user
number_str = input('Enter the number to send to server - ')

try:
    # Encode the string input to bytes before sending
    clientserver.sendto(number_str.encode('utf-8'), serveraddr)

    # Receive the response from the server
    response_bytes, addr = clientserver.recvfrom(1024)

    # Decode the received bytes to a string
    response_str = response_bytes.decode('utf-8')
    print('Server Message - ', response_str)

    # If you need to use the response as a number, convert it to float:
    # response_num = float(response_str)
    # print(f'Server Message (as number) - {response_num}')

except ValueError:
    print("Error: Server response is not a valid number.")
except ConnectionResetError:
    print("ConnectionResetError: The server closed the connection unexpectedly.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
finally:
    # Ensure the socket is closed
    clientserver.close()
    print("Client closed.")
