import socket
from functools import reduce
HOST='localhost'
PORT=5000
def handle_request(number_str,operation):
    numbers=list(map(int,number_str.split(',')))
    if operation== 'map':
        processed=map(lambda x:x*2,numbers)
    elif operation== 'filter':
        processed=filter(lambda x:x%2==0,numbers)
    else:
        return "Invalid Operation"
    reduced_result=reduce(lambda x,y:x+y,processed,0)
    return str(reduced_result)
with socket.socket() as s:
    s.bind((HOST,PORT))
    s.listen()
    print(f'Server listening on {HOST}:{PORT}')
    conn,addr=s.accept()
    with conn:
        print(f'Connected by {addr}')
        data=conn.recv(1024).decode()
        number_str,operation=data.strip().split('|')
        result=handle_request(number_str,operation)
        conn.sendall(result.encode())
    
    
