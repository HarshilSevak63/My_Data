from socket import *

def createClient():
    clientSocket=socket()
    clientSocket.connect(('localhost',9000))
    request='GET / HTTP/1.1\r\n\HOST: localhost\r\n\r\n'
    
    clientSocket.send(request.encode())
    response=clientSocket.recv(1024).decode()
    print('Received message - ')
    print(response)
    clientSocket.close()
createClient()
