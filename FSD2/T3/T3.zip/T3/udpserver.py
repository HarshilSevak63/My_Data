import socket
import time
#SERVER NAME AND ADDRESS
host = 'localhost'
port = 5000
#CREATE SERVER SIDE SOCKET USING TCP
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# SERVER WAITS FOR 5 SECONDS 
time.sleep(5)
# SEND ENCODED MESSAGE TO CLIENT
s.sendto(b"Hello client, How are you?", (host,port))
msg = 'bye'
s.sendto(msg.encode(),(host,port))
# DISCONNECT SERVER
s.close()
