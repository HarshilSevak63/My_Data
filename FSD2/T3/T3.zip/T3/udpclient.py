import socket
# TAKE SERVER NAME AND ADDRESS
host = 'localhost'
port = 5000
#CREATE CLIENT SIDE SOCKET USING TCP
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#CONNECT SOCKET WITH SERVER AND PORT
s.bind((host,port))
# RECEIVE MAX 1024 BYTES MESSAGE FROM SERVER AT A TIME
msg,addr = s.recvfrom(1024)
try :
    # SOCKET BLOCKS AFTER 5 SEC IF SERVER DISCONNECTS
    s.settimeout(5)
    # REPEAT AS LONG AS MSG IS NOT EMPTY
    while msg:
        print("Received - ", msg.decode())
        msg,addr = s.recvfrom(1024)
except socket.timeout:
    print("time is over and hence terminating")
# DISCONNECT SERVER
s.close()
