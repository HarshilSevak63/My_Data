from socket import *

host='0.0.0.0'
port=9000

s=socket.socket()
s.bind((host,port))

s.listen()

c,addr=s.accept()
print('Connaction Established from - ',str(addr))

filename=c.recv(1024).decode()

with open(filename,'wb') as f:
    while True:
        data=c.recv(1024)
        if not data:
            break
        f.write(data)
        
print(f"file {filname} recived successfully")

c.close()
