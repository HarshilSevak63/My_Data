
import socket
import time

host = 'localhost'
port = 5000

# Create a UDP socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# Bind the socket to the address and port (important for servers to receive)
s.bind((host, port)) # Added this line for the server to listen

print('Server Running.....')

try:
    # Receive data from the client
    msg, addr = s.recvfrom(1024)

    # Decode the received message from bytes to string
    # It's good practice to specify encoding, e.g., 'utf-8'
    received_num_str = msg.decode('utf-8')
    print(f'Received message from {addr} - {received_num_str}')

    # Convert the string to a float
    num = float(received_num_str)

    # Calculate the cube
    ans = num ** 3

    # Convert the float result back to a string, then encode it to bytes before sending
    s.sendto(str(ans).encode('utf-8'), addr)

except ValueError:
    print("Error: Received message is not a valid number.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
finally:
    # Ensure the socket is closed even if an error occurs
    s.close()
    print("Server closed.")
