import socket

host='192.168.104.235'
port=9000

s=socket.socket()
s.connect((host,port))

filename=input('Enter file name to send - ')
s.send(filename.encode())

with open(filename,'rb') as f:
    data=f.read(1024)
    while data:
        s.send(data)
        data=f.read(1024)
print(f"file {filename} sent successfully")

s.close()
