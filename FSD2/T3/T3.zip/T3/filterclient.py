import socket
HOST='localhost'
PORT=5000
number='1,2,3,4,5'
operation='filter'
message=f'{number}|{operation}'
with socket.socket() as s:
    s.connect((HOST,PORT))
    s.send(message.encode())
    result=s.recv(1024).decode()
    print('Reduced result from server is - ',result)
