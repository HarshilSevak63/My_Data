from socket import *

def createServer():
    serversocket=socket()
    serversocket.bind(('localhost',9000))
    serversocket.listen()
        
    print('Access - http://localhost:9000')
        
    while True:
        clientsocket,address=serversocket.accept()
        rd=clientsocket.recv(5000).decode()
        print(rd)
        data='HTTP/1.1 200 OK\r\n'
        data+='Content-Type: text/html; charset=utf-8\r\n'
        data+='\r\n'
        data+='<html><body><h1> Hello world</h1></body></html>\r\n\r\n'
        clientsocket.send(data.encode())
        clientsocket.close()
        
    serversocket.close()
createServer()
