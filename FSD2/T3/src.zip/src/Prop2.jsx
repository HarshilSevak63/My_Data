function Prop2(p){
    return (
        <>
        <h1>{p.pname}{p.ename}</h1>
        </>
    )
}

export default Prop2;