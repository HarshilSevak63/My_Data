function Contact(){
    return(
        <>
        <h1>Conatct at: +91 1234567891</h1>
        </>
    );
}

export default Contact;