function Hello(){
    return(
        <div>
            <h1>Hello</h1>
            <h1>World</h1>
        </div>
    );
}

export default Hello;