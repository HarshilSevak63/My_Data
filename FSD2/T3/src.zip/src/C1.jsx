import C2 from './C2.jsx';

function C1(p){
    return(
    <>
    {/* <C2 m={p.msg} /> */}
    <C2/>
    </>
    );
}

export default C1;