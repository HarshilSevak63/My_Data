function Home(){
    return(
        <>
        <h1>Hello Anna</h1>
        <h1>Welcome Anna</h1>
        </>
    );
}

export default Home;