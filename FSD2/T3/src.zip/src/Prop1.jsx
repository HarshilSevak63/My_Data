import Prop2 from './Prop2.jsx';

function Prop1(){
    return(
        <>
        <Prop2 pname='Ganne ka juice'/>
        <Prop2 ename='Bada glass 20 Rs.'/>
        </>
    );
}
export default Prop1;